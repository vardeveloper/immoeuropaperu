<?php

/**
 * WBC Framework
 *
 * This library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @link http://www.hostper.com/
 * @copyright 2007-2009 Wide Business Corporation S.A.C.
 */
class FileService {

    static public function getImg() {

        $imageinfo = explode('-', Ey::getPrm(2));

        $image = $imageinfo[count($imageinfo) - 1];

        if (defined('APP_EXT_IMAGEN')) {
            $file = str_replace('-', DS, strtolower(Ey::getPrm(2))) . '.' . APP_EXT_IMAGEN;
        } else {
            $file = str_replace('-', DS, strtolower(Ey::getPrm(2))) . '.jpg';
        }


        $baseDir = APP_ROOT . DS . '_data' . DS . 'img';

        // Si el parametro 4 esta puesto y tiene como valor 1
        // la ubicación de imagenes se mueve hacia el directorio publico

        if (Ey::getPrm(4) == 1) {
            if (defined('PUBLIC_DIR')) {
                $baseDir = PUBLIC_DIR . DS . 'data' . DS . 'img';
            }
        }


        /* Dirección y nombre del archivo */
        $filename = $baseDir . DS . $file;

        if (!file_exists($filename)) {
            $noImg = $baseDir . DS . 'noimg.jpg';

            if (file_exists($noImg)) {
                $filename = $noImg;

                $image = 'noimg.jpg';
            } else {
                header("HTTP/1.0 404 Not Found");
                exit();
            }
        }


        /* Parametros de dimension x:y */
        $params = Ey::getPrm(3);

        $x = false;
        $y = false;

        if ($params != '') {
            $prmParts = explode(':', $params);
            if (intVal($prmParts[0]) > 0) {
                $x = $prmParts[0];
            }
            if (intval($prmParts[1]) > 0) {
                $y = $prmParts[1];
            }
        }

        $resizedImageSource = $x . 'x' . $y . 'x';

        $resizedImageSource .= '-' . $image;

        $resizedImage = md5($resizedImageSource);


        // Verificar la existencia de la constante CACHE_DIR

        if (!defined('CACHE_DIR')) {
            define('CACHE_DIR', DOC_ROOT . DS . 'cache');

            // Si no existe el direcorio de cache, crearlo
            if (!file_exists(CACHE_DIR)) {
                mkdir(CACHE_DIR);
            }
        }

        $resized = CACHE_DIR . DS . $resizedImage;


        $obj = new Asido_Engine();

        $optimize = false;

        if (defined('USER_IMAGE_FORMAT')) {

            $formatoImagen = USER_IMAGE_FORMAT;

            if (USER_IMAGE_FORMAT == 'image/jpeg') {
                if (defined('OPTIMIZE_IMAGE')) {

                    $optimize = true;
                    $optimizer = OPTIMIZER_JPG . ' -copy none -optimize -progressive ';
                }

                $extension = 'jpg';
            }
        } else {
            $formatoImagen = ASIDO_MIME_PNG;

            if (defined('OPTIMIZE_IMAGE')) {
                $optimize = true;
                $optimizer = OPTIMIZER_PNG;
            }

            $extension = 'png';
        }

        // Nombre temporal del archivo para realizar la optimización
        $tmpResized = $resized;

        if (file_exists($resized)) {

            $imageModified = filemtime($filename);
            $thumbModified = filemtime($resized);


            if ($imageModified > $thumbModified) {

                //replace
                Asido_Engine::driver('gd');


                if ($optimize) {
                    $pathInfo = pathinfo($resized);
                    $tmpResized = $pathInfo['dirname'] . DS . 'tmp_' . $pathInfo['basename'];
                }

                $i1 = Asido_Engine::image($filename, $tmpResized);
                if (($x + $y) > 0) {
                    Asido_Engine::Fit($i1, $x, $y);
                }

                Asido_Engine::convert($i1, $formatoImagen);
                $i1->save(ASIDO_OVERWRITE_ENABLED);

                if ($optimize) {
                    @exec($optimizer . ' ' . $tmpResized . ' ' . $resized);
                    @unlink($tmpResized);
                }
            }
        } else {


            Asido_Engine::driver('gd');

            if ($optimize) {
                $pathInfo = pathinfo($resized);
                $tmpResized = $pathInfo['dirname'] . DS . 'tmp_' . $pathInfo['basename'];
            }


            $i1 = Asido_Engine::image($filename, $tmpResized);

            if (($x + $y) > 0) {
                Asido_Engine::Fit($i1, $x, $y);
            }

            Asido_Engine::convert($i1, $formatoImagen);
            $i1->save(ASIDO_OVERWRITE_ENABLED);

            if ($optimize) {
                exec($optimizer . ' ' . $tmpResized . ' ' . $resized, $output);
                unlink($tmpResized);
            }
        }


        $data = file_get_contents($resized);

        $lastModifiedString = gmdate('D, d M Y H:i:s', $thumbModified) . ' GMT';
        $etag = md5($data);

        header("Expires: " . gmdate("D, d M Y H:i:s", mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 7, date("Y"))) . "GMT");
        header("Cache-control:private, max-age=2592000");
        header('Pragma: !invalid');
        header("Last-Modified: $lastModifiedString");
        header('ETag: ' . $etag);

        $if_none_match = isset($_SERVER['HTTP_IF_NONE_MATCH']) ?
                stripslashes($_SERVER['HTTP_IF_NONE_MATCH']) :
                false;

        $if_modified_since = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ?
                stripslashes($_SERVER['HTTP_IF_MODIFIED_SINCE']) :
                false;

        $changed = false;
        
        if (!$if_modified_since && !$if_none_match) {
            $changed = true;
        }

        if ($if_none_match && $if_none_match != $etag && $if_none_match != '"' . $etag . '"') {
            $changed = true; // etag is there but doesn't match
        }

        if ($if_modified_since && $if_modified_since != $lastModifiedString) {
            $changed = true; // if-modified-since is there but doesn't match
        }

        // Nothing has changed since their last request - serve a 304 and exit
        if (!$changed) {
            if (php_sapi_name() == 'CGI') {
                Header("Status: 304 Not Modified");
            } else {
                Header("HTTP/1.0 304 Not Modified");
            }

            exit();
        }


        //

        header("Content-Description: File Transfer");
        header('Content-disposition: attachment; filename=' . basename($image) . '.' . $extension);
        header("Content-Type: " . $formatoImagen);
        header("Content-Transfer-Encoding: binary");
        header('Content-Length: ' . strlen($data));
        echo $data;
    }

    private function verifyCacheRequestImage($etag, $lastModified) {
        header("Last-Modified: $lastModified");
        header("ETag: \"{$etag}\"");

        $if_none_match = isset($_SERVER['HTTP_IF_NONE_MATCH']) ?
                stripslashes($_SERVER['HTTP_IF_NONE_MATCH']) :
                false;

        $if_modified_since = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ?
                stripslashes($_SERVER['HTTP_IF_MODIFIED_SINCE']) :
                false;

        if (!$if_modified_since && !$if_none_match) {
            return;
        }

        if ($if_none_match && $if_none_match != $etag && $if_none_match != '"' . $etag . '"') {
            return; // etag is there but doesn't match
        }

        if ($if_modified_since && $if_modified_since != $lastModified) {
            return; // if-modified-since is there but doesn't match
        }

        // Nothing has changed since their last request - serve a 304 and exit
        header('HTTP/1.1 304 Not Modified');
        exit();
    }

    /**
     * Envía contenido javascript al navegador
     */
    static public function getJs($module, $index) {
        //ob_start ("ob_gzhandler");  //raul

        $code = Ey::getPrm($index + 3);
        $format = Ey::getPrm($index + 4);

        $view = new Smarty_Engine();

        if ($module != '') {
            $module = DS . $module;
        }


        if ($format == '') {
            header("Content-Encoding: gzip");
            ob_start("ob_gzhandler");
            header('Content-Type: text/javascript');
            header('Content-disposition: attachment; filename=' . $code . '.js');
        } else {
            switch ($format) {
                case 'htc':
                    header('Content-Type: text/x-component');
                    break;
            }
        }

        header("cache-control: must-revalidate"); //raul
        // set variable for duration of cached content
        $offset = 60 * 60;

        // set variable specifying format of expiration header
        $expire = "expires: " . gmdate("D, d M Y H:i:s", time() + $offset) . " GMT";

        // send cache expiration header to the client broswer
        header($expire);

        $js = $view->fetch(APP_ROOT . $module . DS . 'tpl' . DS . 'js.' . $code . '.tpl');

        echo $js;
    }

    static public function getPdf() {

        $file = Ey::fileSafeName(str_replace('-', DS, strtolower(Ey::getPrm(2)))) . '.pdf';

        /* Direcciòn y nombre del archivo */
        $filename = APP_ROOT . DS . '_data' . DS . 'file' . DS . $file;

        if (Ey::getPrm(3) != '') {
            $fileTitle = Ey::getPrm(3) . '.pdf';
        } else {
            $fileTitle = Ey::getPrm(2) . '.pdf';
        }

        FileService::downloadFile($filename, 'application/pdf', $fileTitle);
    }

    static public function getFile() {


        // Nombre y ruta del archivo
        $file = APP_ROOT . DS . '_data' . DS . str_replace('-', DS, strtolower(Ey::getPrm(2)));

        // Titulo del archivo
        $fileTitle = Ey::getPrm(3);

        // info de archivo
        $fileInfo = pathinfo($file);

        // Nombre base del archivo (file.ext)
        $filename = $fileInfo['basename'];

        // Verificar el titulo del archivo, si vacio, usar el nombre del
        // archivo fisico

        if ($fileTitle != '') {
            $fileTitle.='.' . $fileInfo['extension'];
        } else {
            $fileTitle = $filename;
        }

        // Obtener el mime-type del archivo
        $mime = FileService::getMime($filename);

        // Enviar al archivo para descarga
        FileService::downloadFile($file, $mime, $fileTitle);
    }

    static public function getSwf() {

        $ext = Ey::getPrm(3);

        if ($ext == '') {
            $ext = 'jpg';
        }

        $file = Ey::fileSafeName(str_replace('-', DS, strtolower(Ey::getPrm(2)))) . '.' . $ext;

        /* Direcciòn y nombre del archivo */
        $filename = APP_ROOT . DS . '_data' . DS . 'file' . DS . $file;

        $strfile = file_get_contents($filename);

        header('Content-Type: application/x-shockwave-flash');
        header("Expires: Thu, 01 Jan 1970 00:00:00 GMT, -1 ");
        header("Cache-Control: no-cache, no-store, must-revalidate");
        header("Pragma: no-cache");

        // FileService::downloadFile($filename,'application/x-shockwave-flash');
        echo $strfile;
    }

    static public function downloadFile($file, $mime, $fileTitle='', $return=false) {
        // mime para Zip : application/zip

        if (!file_exists($file)) {
            header("HTTP/1.0 404 Not Found");
            exit();
        }

        header('Content-Description: File Transfer');
        header('Content-Type: ' . $mime);
        header('Content-Disposition: attachment; filename=' . $fileTitle);
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();
        readfile($file);

        if ($return) {
            return;
        }

        exit();
    }

    static public function getMime($filename) {
        $mime_types = array(
            'txt' => 'text/plain',
            'htm' => 'text/html',
            'html' => 'text/html',
            'php' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'swf' => 'application/x-shockwave-flash',
            'flv' => 'video/x-flv',
            // images
            'png' => 'image/png',
            'jpe' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'jpg' => 'image/jpeg',
            'gif' => 'image/gif',
            'bmp' => 'image/bmp',
            'ico' => 'image/vnd.microsoft.icon',
            'tiff' => 'image/tiff',
            'tif' => 'image/tiff',
            'svg' => 'image/svg+xml',
            'svgz' => 'image/svg+xml',
            // archives
            'zip' => 'application/zip',
            'rar' => 'application/x-rar-compressed',
            'exe' => 'application/x-msdownload',
            'msi' => 'application/x-msdownload',
            'cab' => 'application/vnd.ms-cab-compressed',
            // audio/video
            'mp3' => 'audio/mpeg',
            'qt' => 'video/quicktime',
            'mov' => 'video/quicktime',
            // adobe
            'pdf' => 'application/pdf',
            'psd' => 'image/vnd.adobe.photoshop',
            'ai' => 'application/postscript',
            'eps' => 'application/postscript',
            'ps' => 'application/postscript',
            // ms office
            'doc' => 'application/msword',
            'rtf' => 'application/rtf',
            'xls' => 'application/vnd.ms-excel',
            'ppt' => 'application/vnd.ms-powerpoint',
            // open office
            'odt' => 'application/vnd.oasis.opendocument.text',
            'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
            // MS Office 2007

            'docm' => 'application/vnd.ms-word.document.macroEnabled.12',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'dotm' => 'application/vnd.ms-word.template.macroEnabled.12',
            'dotx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
            'potm' => 'application/vnd.ms-powerpoint.template.macroEnabled.12',
            'potx' => 'application/vnd.openxmlformats-officedocument.presentationml.template',
            'ppam' => 'application/vnd.ms-powerpoint.addin.macroEnabled.12',
            'ppsm' => 'application/vnd.ms-powerpoint.slideshow.macroEnabled.12',
            'ppsx' => 'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
            'pptm' => 'application/vnd.ms-powerpoint.presentation.macroEnabled.12',
            'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'xlam' => 'application/vnd.ms-excel.addin.macroEnabled.12',
            'xlsb' => 'application/vnd.ms-excel.sheet.binary.macroEnabled.12',
            'xlsm' => 'application/vnd.ms-excel.sheet.macroEnabled.12',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'xltm' => 'application/vnd.ms-excel.template.macroEnabled.12',
            'xltx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.template'
        );

        $ext = strtolower(array_pop(explode('.', $filename)));
        if (array_key_exists($ext, $mime_types)) {
            return $mime_types[$ext];
        } elseif (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME);
            $mimetype = finfo_file($finfo, $filename);
            finfo_close($finfo);
            return $mimetype;
        } else {
            return 'application/octet-stream';
        }
    }

}

/*
  <?php
  $zip = new ZipArchive;
  if ($zip->open('test.zip') === TRUE) {
  $zip->addFile('/path/to/index.txt', 'newname.txt');
  $zip->close();
  echo 'ok';
  } else {
  echo 'failed';
  }

  $fp = @fopen($s, 'rb');
 */