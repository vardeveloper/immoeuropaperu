<?php
/**
 * bdo tag class
 *
 * The bdo element overrides the default
 * text direction.
 *
 * REQUIRED ATTRIBUTE
 *  dir : url
 * @package DOM
 *
 */
class BDOtag extends HTMLTagClass {
    protected $_tag = "bdo";

    /**
     * The factory method for this tag.
     *
     * @param string the dir attribute
     * @return BDOtag object
     */
    public static function factory($dir) {
        $attributes = array('dir' => $dir);
        $num_args = func_num_args();
        if ($num_args<=1) {
            $obj = new BDOtag($attributes);
        } else {
            $arg_list = func_get_args();
            array_shift($arg_list);
            $obj = new BDOtag($attributes, $arg_list);
        }
        return $obj;
    }

} // BDOtag