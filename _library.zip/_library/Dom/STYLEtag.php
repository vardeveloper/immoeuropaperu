<?php
/**
 * style tag class
 *
 * Defines a style in a document. The style
 * element goes in the head section. If you
 * want to include a style sheet in your page,
 * you should define the style sheet externally,
 * and link to it using link.
 *
 * REQUIRED ATTRIBUTES
 *  type : text/css, text/javascript
 * @package DOM
 */
class STYLEtag extends HTMLTagClass {
    protected $_tag = "style";

    /**
     * The factory method.
     *
     * @param string type attribute
     * @param mixed n number of arguments
     *                as content for the tag.
     * @return STYLEtag object
     */
    public static function factory($type="text/css") {
        $attributes = array('type' => $type);
        $num_args = func_num_args();
        if ($num_args<=1) {
            $obj = new STYLEtag($attributes);
        } else {
            $arg_list = func_get_args();
            array_shift($arg_list);
            $obj = new STYLEtag($attributes, $arg_list);
        }
        return $obj;
    }
} // STYLEtag