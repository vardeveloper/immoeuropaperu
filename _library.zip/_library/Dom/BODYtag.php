<?php
/**
 * body tag class
 *
 * Defines the documents' body.
 *
 * OPTIONAL ATTRIBUTES (all depricated)
 *   alink => color : DEPRICATED
 *   background => filename : DEPRICATED
 *   bgcolor => color : DEPRICATED
 *   link => color : DEPRICATED
 *   text => color : DEPRICATED
 *   vlink => color : DEPRICATED
 *
 * @package DOM
 */
class BODYtag extends HTMLTagClass {
    protected $_tag = "body";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return BODYtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new BODYtag;
        } else {
            $arg_list = func_get_args();
            return new BODYtag(NULL, $arg_list);
        }
    }

} // BODYtag