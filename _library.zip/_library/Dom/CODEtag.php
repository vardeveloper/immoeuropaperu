<?php
/**
 * code tag class
 *
 * Defines computer code text.
 *
 * @package DOM
 */
class CODEtag extends HTMLTagClass {
    protected $_tag = "code";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return CODEtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new CODEtag;
        } else {
            $arg_list = func_get_args();
            return new CODEtag(NULL, $arg_list);
        }
    }

} // CODEtag