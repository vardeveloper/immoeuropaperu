<?php
/**
 * button tag class
 *
 *  Defines a push button.
 *
 * @package DOM
 */
class BUTTONtag extends HTMLTagClass {
    protected $_tag = "button";

    /**
     * The factory method for this tag.
     *
     * @param string the type attribute
     * @return BUTTONtag object
     */
    public static function factory($type='button') {
        $attributes = array('type' => $type);
        $num_args = func_num_args();
        if ($num_args<=1) {
            $obj = new BUTTONtag($attributes);
        } else {
            $arg_list = func_get_args();
            array_shift($arg_list);
            $obj = new BUTTONtag($attributes, $arg_list);
        }
        return $obj;
    }

} // BUTTONtag