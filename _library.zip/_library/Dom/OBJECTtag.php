<?php
/**
 * object tag class
 *
 * Defines an embedded object. Use this element
 * to insert  multimedia into your page.
 *
 * @package DOM
 */
class OBJECTtag extends HTMLTagClass {
    protected $_tag = "object";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return OBJECTtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new OBJECTtag;
        } else {
            $arg_list = func_get_args();
            return new OBJECTtag(NULL, $arg_list);
        }
    }
} // OBJECTtag