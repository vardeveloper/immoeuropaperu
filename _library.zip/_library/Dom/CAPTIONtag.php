<?php
/**
 * caption tag class
 *  This element defines a table caption.
 *  The <caption> tag must be inserted immediately
 *  after the <table> tag. You can specify only one
 *  caption per table.
 *
 * OPTIONAL ATTRIBUTES
 *  align  - top, bottom   DEPRICATED
 *
 * @package DOM
 */
class CAPTIONtag extends HTMLTagClass {
    protected $_tag = "caption";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return CAPTIONtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new CAPTIONtag;
        } else {
            $arg_list = func_get_args();
            return new CAPTIONtag(NULL, $arg_list);
        }
    }

} // CAPTIONtag