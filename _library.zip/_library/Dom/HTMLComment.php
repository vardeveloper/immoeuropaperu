<?php
/**
 * HTMLComment Class
 * @package DOM
 */
class HTMLComment
{
  public static function factory($string) 
  {
    return '<!-- ' . $string . ' //-->';
  }
  
}