<?php
/**
 * abbr tag class
 * @package DOM
 */
class ABBRtag extends HTMLTagClass {
    protected $_tag = "abbr";

    /**
     * build an <ABBR> tag with content.
     *
     *  This is to build an abbreviation.
     *  normally its just
     *  <abbr title="foo bar">foo</abbr>
     *
     * @param string - the title attribute
     * @param mixed - the content for the tag
     * @return  ABBRtag object.
     */
    public static function factory($title, $content) {
        return new ABBRtag(array("title"=>$title), $content);
    }
} // ABBRtag