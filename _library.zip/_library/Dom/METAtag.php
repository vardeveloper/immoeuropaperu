<?php
/**
 * meta tag class
 *
 * The meta element provides meta-information
 * about your page, such as descriptions and
 * keywords for search engines.
 *
 * NOTE: The meta tag always goes inside the head element.
 *
 * REQUIRED ATTRIBUTES
 *  content : text
 *            Sets meta information to be associated
 *            with http-equiv or name.
 *
 * @package DOM
 */
class METAtag extends HTMLTagClass {
    protected $_tag = "meta";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}

     /**
     * The factory method.
     *
     * @param string the name attribute
     * @param   mixed n number of arguments
     *                as content for the tag.
     * @return METAtag object
     */
    public static function factory($content, $http_equiv="", $name="") {
        $attributes = array("content" => $content);

        if ($http_equiv != "") {
            $attributes["http-equiv"] = $http_equiv;
        }

        if ($name != "") {
            $attributes["name"] = $name;
        }

        return new METAtag( $attributes );
    }


    /**
     * This is a helper method to build a proper META
     * tag that includes refreshing to a url
     *
     * @param string $url full http url to go to
     * @param int $time how many seconds until refresh
     */
    public static function factory_refresh($url, $time) {
        return self::factory($time.';url='.$url, 'refresh');
    }
} // METAtag