<?php
/**
 * Table Header th class.
 *
 * Defines a header cell in a table.
 * Very much the same as a data cell,
 * but rendered in bold and with a default
 * center alignment.
 *
 * OPTIONAL ATTRIBUTES
 * same as TDtag
 *
 * STANDARD ATTRIBUTES
 *  same as TDtag
 *
 * EVENT ATTRIBUTES
 *   same as TDtag
 *
 * @package DOM
 */
class THtag extends HTMLTagClass {
    protected $_tag = "th";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return THtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new THtag;
        } else {
            $arg_list = func_get_args();
            return new THtag(NULL, $arg_list);
        }
    }

    /**
     * This is a helper for setting the colspan
     * attribute
     *
     * @param int - the colspan value
     */
    public function set_colspan($colspan) {
        $this->set_tag_attribute('colspan', (int)$colspan);
    }

    /**
     * This is a helper for setting the rowspan
     * attribute
     *
     * @param int - the rowspan value
     */
    public function set_rowspan($rowspan) {
        $this->set_tag_attribute('rowspan', (int)$rowspan);
    }
} // <TH>