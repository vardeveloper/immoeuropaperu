<?php
/**
 * dfn tag class
 *
 *  Defines a definition term
 *
 * @package DOM
 */
class DFNtag extends HTMLTagClass {
    protected $_tag = "dfn";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return DFNtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new DFNtag;
        } else {
            $arg_list = func_get_args();
            return new DFNtag(NULL, $arg_list);
        }
    }

} // DFNtag