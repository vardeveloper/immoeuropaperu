<?php
/**
 * xml tag class
 * @package DOM
 */
class XMLtag extends XMLTagClass {
    var $_tag = "xml";
    var $_tag_prefix = "<?";
    var $_tag_postfix = " ?>";

    function __construct( $attributes=array() ) {
		parent::__construct( $this->_tag, $attributes);
        $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
        $this->_flags |= DOM::_ALWAYS_LOWERCASE | DOM::_NOFINISHSLASHXHTML;

		$num_args = func_num_args();
        for ($i=1;$i<$num_args;$i++) {
            $this->add(func_get_arg($i));
        }
    }

} // XMLtag