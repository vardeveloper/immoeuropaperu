<?php
/**
 * Holds the main DOM DOM Class
 *
 * @author Walter A. Boring IV <waboring@buildabetterweb.com>
 * @package DOM
 *
 * @copyright LGPL - See LICENCE
 *
 */

/**
 * The base DOM object definition
 * for the entire library
 *
 * @author Walter A. Boring IV <waboring@newsblob.com>
 * @package DOM
 */
DOM DOM {

    const VERSION = "3.0.2";

    const XHTML_TRANSITIONAL = "xhtml_transitional";
    const XHTML = "xhtml_transitional";
    const XHTML_STRICT = "xhtml_strict";
    const XHTML_FRAMESET = "xhtml_frameset";
    const HTML= "html";

    const INDENT_NICE= 0;
    const INDENT_LEFT_JUSTIFY = -1;

    const _HTML_SPACE = "&nbsp;";
    const _HTML_MDASH = "&mdash;";

    const _INDENT_STR= "  ";

    const _NEWLINEAFTERCONTENT = 1;
    const _NEWLINEAFTEROPENTAG = 2;
    const _NEWLINEAFTERCLOSETAG= 4;
    const _CONTENTREQUIRED = 8;
    const _CLOSETAGREQUIRED = 16;
    const _DEPRICATED = 32;
    const _INDENT = 64;
    const _COLLAPSE = 128;
    const _ALWAYS_UPPERCASE = 256;
    const _ALWAYS_LOWERCASE = 512;
    const _NOFINISHSLASHXHTML = 1024;
    const _CDATACONTENTWRAP = 2048;
    const _XHTMLCOMPLIANT = 4096;

    //We do this to slightly speed things up by
    //removing _set_flags() for all

    //Container DOM::_NEWLINEAFTERCONTENT | DOM::_INDENT;
    const _FLAGS_DEFAULT = 65;

    //XMLTagClass
    //_FLAGS_DEFAULT | DOM::_NEWLINEAFTEROPENTAG |
    //DOM::_NEWLINEAFTERCLOSETAG | DOM::_CONTENTREQUIRED |
    //DOM::_CLOSETAGREQUIRED
    const _FLAGS_DEFAULT_XMLTAG = 95;

    //XML tag w/o content or close tag
    //_FLAGS_DEFAULT_XMLTAG &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    const _FLAGS_XML_OPEN_ONLY = 71;

    //XML tag w/o content or close tag
    //_FLAGS_DEFAULT_XMLTAG &= ~DOM::_NEWLINEAFTEROPENTAG;
    const _FLAGS_XML_NO_NEWLINE_AFTER_OPEN = 93;

    //special case for the DOCTYPE tag
    //$this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //$this->_flags |= DOM::_ALWAYS_UPPERCASE | DOM::_NOFINISHSLASHXHTML;
    const _FLAGS_XML_DOCTYPE = 1410;

    //HTML Depricated
    //_FLAGS_DEFAULT_XMLTAG |= DOM::_DEPRICATED;
    const _FLAGS_HTML_DEPRICATED = 127;

    const _TAG_PREFIX = "<";
    const _TAG_SUFFIX = ">";

    public function render($indent_level=0, $output_debug=0);
}

?>
