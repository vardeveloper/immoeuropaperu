<?php
/**
 * nobr tag class
 *
 * NOTE: This tag doesn't really
 *       exist in the HTML spec
 *       NOT WISE TO USE IT.
 * @deprecated
 * @package DOM
 */
class NOBRtag extends HTMLTagClass {
    protected $_tag = "nobr";
    protected $_flags = DOM::_FLAGS_HTML_DEPRICATED;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags |= DOM::_DEPRICATED;
    //}
} // NOBRtag