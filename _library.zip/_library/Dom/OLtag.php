<?php
/**
 * ol tag class
 *
 * The ol tag defines the start of an ordered list.
 *
 * OPTIONAL ATTRIBUTES
 *   type : 1,A,a,I,i  DEPRICATED DO NOT USE
 *
 * @package DOM
 */
class OLtag extends HTMLTagClass {
    protected $_tag = "ol";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return OLtag object
     */
    public static function factory() {
        //we need to make sure all arguments
        //pass through the add method
        //because add automagically converts
        //strings to LItag objects.
        $tag = new OLtag;
        $num_args = func_num_args();
        if ($num_args >= 1) {
            $arg_list = func_get_args();
            foreach( $arg_list as $arg) {
                $tag->add($arg);
            }
        }

        return $tag;
    }


    /**
     * add content onto content stack
     * adds content to tag as a FIFO.
     * You can have n number of parameters.
     * each one will get added in succession to the content.
     *
     * we override this from the parent so we can auto detect if
     * the user is adding raw strings instead of objects.
     * If they are trying to add raw strings, then we wrap that in
     * an LItag object, since you can't add anything other then an <LI>
     * @param   mixed   $content - either string, or tag object.
     * @access  public
     */
    function add() {
        $args = func_get_args();

        foreach( $args as $content) {

            if (!is_object($content) || (@$content->get_tag_name() != "li") ) {
                //$content is raw (string)
                //lets wrap it in a <LI> object
                $li = new LItag;
                $li->add( $content );
                parent::add( $li );
            } else {
                //looks like this is some object
                //let the user do it.
                //should we only let them push a
                //<LI> object?
                parent::add( $content );
            }
        }
    }

} // OLtag