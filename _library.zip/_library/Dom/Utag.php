<?php
/**
 * u tag class
 * @package DOM
 */
class Utag extends HTMLTagClass {
    protected $_tag = "u";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return Utag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new Utag;
        } else {
            $arg_list = func_get_args();
            return new Utag(NULL, $arg_list);
        }
    }
} // Utag