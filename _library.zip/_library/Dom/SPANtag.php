<?php
/**
 * span tag class
 *
 * The span tag defines a section in a document.
 *
 * NOTE: Browsers do not place a line break before
 *       or after the span tag.
 *
 * @package DOM
 */
class SPANtag extends HTMLTagClass {
    protected $_tag = "span";

    /**
     * The factory method.
     *
     * @param string label attribute
     * @param mixed n number of arguments
     *                as content for the tag.
     * @return SPANtag object
     */
    public static function factory($class="") {
        if ($class == "") {
            $attributes = NULL;
        } else {
            $attributes = array('class' => $class);
        }

        $arg_list = func_get_args();
        array_shift($arg_list);
        $obj = new SPANtag($attributes, $arg_list);
        return $obj;
    }
} // SPANtag