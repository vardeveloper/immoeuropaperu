<?php
/**
 * script tag class
 *
 * Defines a script, such as JavaScript.
 *
 * REQUIRED ATTRIBUTES
 *  type : text/ecmascript, text/javascript,
 *         text/jscript, text/vbscript,
 *         text/vbs, text/xml
 *         The MIME type of the script.
 *
 * OPTIONAL ATTRIBUTES
 *  language : javascript, livescript, vbscript
 *             other   DEPRICATED DO NOT USE
 *
 * @package DOM
 */
class SCRIPTtag extends HTMLTagClass {
    protected $_tag = "script";

    /**
     * The factory method.
     *
     * @param string the src attribute
     * @param string the type attribute
     * @return SCRIPTtag object
     */
    public static function factory($src="", $type="text/javascript") {
        $attributes = array("type" => $type);
        if ($src != "") {
            $attributes["src"] = $src;
        }
        return new SCRIPTtag( $attributes );
    }
} // SCRIPTtag