<?php
/**
 * ul tag class
 * @package DOM
 */
class ULtag extends OLtag {
    protected $_tag = "ul";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return ULtag object
     */
    public static function factory() {
        //we need to make sure all arguments
        //pass through the add method
        //because add automagically converts
        //strings to LItag objects.
        $tag = new ULtag;
        $num_args = func_num_args();
        if ($num_args >= 1) {
            $arg_list = func_get_args();
            foreach( $arg_list as $arg) {
                $tag->add($arg);
            }
        }

        return $tag;
    }
} // ULtag