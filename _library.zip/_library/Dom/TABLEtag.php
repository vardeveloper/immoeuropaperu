<?php
/**
 * table tag class
 *
 * The table tag defines the start of a table.
 * Inside a table row you can put table headers,
 * table rows, and table cells.
 * @package DOM
 *
 */
class TABLEtag extends HTMLTagClass {
    protected $_tag = "table";


    /**
     * Holds the default attributes for all <tr>'s
     * @var array
     * @private
     */
    protected $_default_row_attributes = NULL;

    /**
     * Holds the default attributes for all <td>'s
     * @var array
     * @private
     */
    protected $_default_col_attributes = NULL;


    /**
     * The factory method.
     *
     * @param string the width attribute
     * @param string the border attribute
     * @param string the cellspacing attribute
     * @param string the cellpadding attribute
     * @param string the align attribute
     * @return TABLEtag object
     */
    public static function factory($width="100%", $border="0",
                                   $cellspacing="0",
                                   $cellpadding="0",$align=NULL) {
        $attributes = array( "width" => $width,
                             "border" => $border,
                             "cellspacing" => $cellspacing,
                             "cellpadding" => $cellpadding);

        if ($align != NULL) {
            $attributes["align"] = $align;
        }
        return new TABLEtag( $attributes );
    }



    //****************************************************************
    // Table specific routines.
    //****************************************************************



    /**
     * push 1 row (tr) of content.
     * Content can be raw strings, or tag objects.
     * Can push 1 item, or multiple items in call.  Each item
     * will be its own td.  should call push() to push a
     * <TR> object, but we detect it here anyway.
     * This function does not save the content by reference.
     * It copies the content and pushes it into the table.
     * If you want to save a reference use push() instead.
     * @param   mixed    $args    The <td>'s to push for next row
     * @return  string
     * @public
     */

    public function add_row() {
        $args = func_get_args();
        $tr = new TRtag( $this->_default_row_attributes );
        $tr->set_default_td_attributes( $this->_default_col_attributes );

        for ($x=0; $x <= func_num_args()-1; $x++) {
            if (is_object($args[$x])) {
                if ($args[$x] instanceOf TDtag) {
                    $tr->add( $args[$x] );
                } else if ($args[$x] instanceOf TRtag) {
                    //the user is trying to use this
                    //to add a TR object.
                    if ($tr->count_content() >= 1) {
                        //there is already content in
                        //the current tr.  This is an
                        //error, since it doesn't make
                        //sense to add data and a row
                        //inside a row.
                        return -1;
                    } else {
                        //user is using this to add
                        //a row. We'll only add it then
                        //bail.
                        $tr = $args[$x];
                        break;
                    }
                } else {
                    //we need to wrap this in its own td.
                    $tr->add( $args[$x] );
                }
            } else {
                //user is adding raw string.
                //lets wrap it in a <tr><td>content</td></tr>
                $tr->add( $args[$x] );
            }

        }
        $this->add( $tr );
    }

    /**
     * Sets the default attributes for <tr>'s
     * that are added to the table.  If there are
     * any attributes set for the <tr> it won't use
     * the defaults.
     *
     * {@source }
     * @param array $attributes - the default attributes
     * @return none
     */
    public function set_default_row_attributes( $attributes=array() ) {
        //should be an array
        $this->_default_row_attributes = $attributes;
    }

    /**
     * Sets the default attributes for <td>'s
     * that are added to the table.  If there are
     * any attributes set for the <td> it won't use
     * the defaults.
     *
     * {@source }
     * @param array $attributes - the default attributes
     * @return none
     */
    public function set_default_col_attributes( $attributes=array() ) {
        //should be an array
        $this->_default_col_attributes = $attributes;
    }



    /**
     * update the attributes of a particular element or td.
     *
     * {@source }
     * @param int $row    row # of the table to edit
     * @param int $col    column # of the table to edit
     * @param array   $attributes array of name=>value pairs
     * @return none
     */
    public function set_cell_attributes( $row, $col, $attributes=array() ) {

        if (is_object($this->_content[$row])) {
            if (is_object($this->_content[$row]->_content[$col])) {
                $this->_content[$row]->_content[$col]->set_tag_attributes( $attributes);
            }
        }
    }

    /**
     * update the attributes of a particular row or tr.
     *
     * {@source }
     * @param int $row    row # of the table to edit
     * @param int $col    column # of the table to edit
     * @param array   $attributes array of name=>value pairs
     * @return mixed -1 if the row doesn't exist already
     */
    public function set_row_attributes( $row, $attributes ) {
        if ($this->_content[$row]) {
            $this->_content[$row]->set_tag_attributes( $attributes );
        } else {
            return -1;
        }
    }

    /**
     * This method sets/resets the content for a specific
     * cell in the table
     *
     * {@source }
     * @param int the row number
     * @param int the column number
     * @param mixed the cell content
     * @return mixed -1 if the cell doesn't exist already
     */
    public function set_cell_content( $row, $col, $content) {

        $item = &$this->_get_element($row);
        if ( is_object($item) ) {
            $item = &$item->_get_element($col);
            if (is_object($item)) {
                $item->reset_content( $content );
            } else {
                return -1;
            }
        } else {
            return -1;
        }
    }

    /**
     * This method is used to set a summary
     * attribute on the table for speech-synthesizing
     * non-visual browsers
     *
     * {@source }
     * @param string the summary
     * @return none
     */
    public function set_summary($summary) {
        $this->set_tag_attribute("summary", $summary);
    }

} // TABLEtag