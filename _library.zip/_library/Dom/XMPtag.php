<?php
/**
 * xmp tag class
 * @package DOM
 */
class XMPtag extends HTMLTagClass {
    protected $_tag = "xmp";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return XMPtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new XMPtag;
        } else {
            $arg_list = func_get_args();
            return new XMPtag(NULL, $arg_list);
        }
    }
} // XMPtag