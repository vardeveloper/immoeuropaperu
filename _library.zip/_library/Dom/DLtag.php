<?php
/**
 * dl tag class
 *
 * The dl tag defines the start of a
 * definition list.
 *
 * @package DOM
 */
class DLtag extends HTMLTagClass {
    protected $_tag = "dl";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return DLtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new DLtag;
        } else {
            $arg_list = func_get_args();
            return new DLtag(NULL, $arg_list);
        }
    }

} // DLtag