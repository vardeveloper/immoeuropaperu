<?php
/**
 * img tag class
 *
 * This element inserts an image.
 *
 * REQUIRED ATTRIBUTES
 *  src : url
 *        The address of the image you want
 *        to insert
 *  alt : text
 *        A short description of the image.
 *        Use it for text-only browsers
 *
 * @package DOM
 */
class IMGtag extends HTMLTagClass {
    protected $_tag = "img";
    //protected $_xhtml_strict_attributes = array("border");
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}


    /**
     * The factory method.
     *
     * @param   string image src
     * @param   int    width of the image.
     * @param   int    height of the image
     * @param   int    border flag.
     * @param   string alt tag for the image
     * @param   string the image map name
     * @param   string the align attribute
     * @param   string the full path
     *                 to the filename.  If this is set
     *                 and $width == '' and $height == ''
     *                 then we will try and determine the
     *                 size attributes of the image.
     * @return IMGtag object
     */
    public static function factory($image, $width='', $height='', $border=0,
                                   $alt="", $usemap=NULL, $title=NULL,
                                   $align=NULL, $filename=NULL) {

        $attributes = array( "src" => $image,
                             "border" => $border,
                             "alt" => $alt);

        if ($height != '') {
            $attributes["height"] = $height;
        }
        if ($width != '') {
            $attributes["width"] = $width;
        }

        if ($height === '' && $width === ''
            && $filename !== NULL) {

            $img = getimagesize($filename);
            if ($img) {
                $attributes['width'] = $img[0];
                $attributes['height'] = $img[1];
            }
        }

        //only add usemap entry if its not NULL
        if ($usemap) {
            $attributes["usemap"] = $usemap;
        }

        if ($title) {
            $attributes["title"] = $title;
        }

        if ($align != NULL) {
            $attributes["align"] = $align;
        }
        return new IMGtag( $attributes );
    }

    /**
     * This method is a wrapper for IMGtag::factory() that
     * allows us to automatically set the width, and
     * height based upon the discovered image attributes.
     *
     * NOTE: This assumes the $image includes a path which
     *       is on the local filesystem based off of the
     *       DOCUMENT_ROOT
     *
     *       So if DOCUMENT_ROOT = /www/mysite.com/html
     *       and $image = '/images/foo.jpg'
     *
     *       getimagesize will look in
     *       $_SERVER['DOCUMENT_ROOT'].$image
     *
     * @param   string image src
     * @param   int    border flag.
     * @param   string alt tag for the image
     * @param   string the image map name
     * @param   string the align attribute
     * @return IMGtag object
     */
    public static function factory_local($image, $border=0, $alt='', $usemap=NULL,
                                         $title=NULL, $align=NULL) {
        return IMGtag::factory($image, '', '', $border, $alt, $usemap,
                               $title, $align, $_SERVER['DOCUMENT_ROOT'].$image);
    }

} // IMGtag