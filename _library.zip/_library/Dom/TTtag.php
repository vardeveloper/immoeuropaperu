<?php
/**
 * tt tag class
 * @package DOM
 */
class TTtag extends HTMLTagClass {
    protected $_tag = "tt";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return TTtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new TTtag;
        } else {
            $arg_list = func_get_args();
            return new TTtag(NULL, $arg_list);
        }
    }
} // TTtag