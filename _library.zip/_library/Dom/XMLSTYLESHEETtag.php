<?php
/**
 * xml-stylesheet tag class
 * @package DOM
 */
class XMLSTYLESHEETtag extends XMLtag {
    var $_tag = "xml-stylesheet";
} // XMLSTYLESHEETtag