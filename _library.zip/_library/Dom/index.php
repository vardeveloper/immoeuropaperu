<?php

$root=dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR 
                        . 'core';

include_once($root . DIRECTORY_SEPARATOR . 'lib.start.php');

?>