<?php
/**
 * param tag class
 *
 *  The param element allows you to specify
 *  the run-time settings for an object inserted
 *  into HTML documents.
 *
 *  REQUIRED ATTRIBUTES
 *   name : the name of the param
 *
 * @package DOM
 */
class PARAMtag extends HTMLTagClass {
    protected $_tag = "param";

    /**
     * The factory method.
     *
     * @param string name attribute
     * @param string value attribute
     * @return PARAMtag object
     */
    public static function factory($name, $value="") {
        $attributes = array("name" => $name);
        if ($value != "") {
            $attributes["value"] = $value;
        }
        return new PARAMtag( $attributes );
    }
} // PARAMtag