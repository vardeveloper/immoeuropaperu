<?php
/**
 * samp tag class
 *
 * Defines sample computer code.
 *
 * @package DOM
 */
class SAMPtag extends HTMLTagClass {
    protected $_tag = "samp";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return SAMPtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new SAMPtag;
        } else {
            $arg_list = func_get_args();
            return new SAMPtag(NULL, $arg_list);
        }
    }
} // SAMPtag