<?php
/**
 * applet tag class
 * @package DOM
 *
 * @deprecated
 */
class APPLETtag extends HTMLTagClass {
    protected $_tag = "applet";
    protected $_flags = DOM::_FLAGS_HTML_DEPRICATED;

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return APPLETtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new APPLETtag;
        } else {
            $arg_list = func_get_args();
            return new APPLETtag(NULL, $arg_list);
        }
    }

} // APPLETtag