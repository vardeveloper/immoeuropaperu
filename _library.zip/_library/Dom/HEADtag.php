<?php
/**
 *  head tag class
 *
 * The head element can contain information
 * about the document.
 *
 * @package DOM
 */
class HEADtag extends HTMLTagClass {
    protected $_tag = "head";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return HEADtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new HEADtag;
        } else {
            $arg_list = func_get_args();
            return new HEADtag(NULL, $arg_list);
        }
    }
} // HEADtag