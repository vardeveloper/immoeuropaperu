<?php
/**
 * optgroup tag class
 *
 *  Defines an option group. This element allows
 *  you to group choices. When you have a long list
 *  of options, groups of related choices are easier
 *  to handle.
 *
 * @package DOM
 */
class OPTGROUPtag extends HTMLTagClass {
    protected $_tag = "optgroup";

    /**
     * The factory method.
     *
     * @param string label attribute
     * @param mixed n number of arguments
     *                as content for the tag.
     * @return OPTGROUPtag object
     */
    public static function factory($label) {
        $attributes = array('label' => $label);
        $num_args = func_num_args();
        if ($num_args<=1) {
            $obj = new OPTGROUPtag($attributes);
        } else {
            $arg_list = func_get_args();
            array_shift($arg_list);
            $obj = new OPTGROUPtag($attributes, $arg_list);
        }
        return $obj;
    }
} // OPTGROUPtag