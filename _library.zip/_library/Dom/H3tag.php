<?php
/**
 * h3 tag class
 *
 * Defines a header
 *
 * @package DOM
 */
class H3tag extends HTMLTagClass {
    protected $_tag = "h3";
    protected $_flags = DOM::_FLAGS_XML_NO_NEWLINE_AFTER_OPEN;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~DOM::_NEWLINEAFTEROPENTAG;
    //}

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return H3tag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            $obj = new H3tag;
        } else {
            $arg_list = func_get_args();
            $obj = new H3tag(NULL, $arg_list);
        }
        $obj->set_collapse();
        return $obj;
    }
} // H3tag