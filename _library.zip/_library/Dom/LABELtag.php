<?php
/**
 * label tag class
 *
 * Defines a label to a control. If you
 * click the text within the label element,
 * it is supposed to toggle the control.
 *
 * NOTE: The "for" attribute binds a label
 *       to another element. Set the value
 *       of the "for" attribute equal to the
 *       value of the "id" attribute of the
 *       related element.
 *
 * @package DOM
 */
class LABELtag extends HTMLTagClass {
    protected $_tag = "label";

    /**
     * The factory method.
     *
     * @param   string - the id of the form
     *                   element to tie this
     *                   label to.
     * @return LABELtag object
     */
    public static function factory($for="") {
        $attributes = array('for' => $for);
        $num_args = func_num_args();
        if ($num_args<=1) {
            $obj = new LABELtag($attributes);
        } else {
            $arg_list = func_get_args();
            array_shift($arg_list);
            $obj = new LABELtag($attributes, $arg_list);
        }
        return $obj;
    }
} // LABELtag