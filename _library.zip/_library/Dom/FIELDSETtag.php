<?php
/**
 * fieldset tag class
 *
 *  The fieldset element draws a box
 *  around the text and other elements
 *  it contains.
 *
 * @package DOM
 */
class FIELDSETtag extends HTMLTagClass {
    protected $_tag = "fieldset";

    /**
     * The factory method for this tag.
     *
     * @param string the type attribute
     * @return BUTTONtag object
     */
    public static function factory($legend="") {
        $arg_list = func_get_args();

        if (!empty($legend)) {
            if (!is_object($legend)) {
                $legend = LEGENDtag::factory($legend);
            }

            array_shift($arg_list);
            array_unshift($arg_list, $legend);
            $obj = new FIELDSETtag(NULL, $arg_list);
        } else {
            array_shift($arg_list);
            $obj = new FIELDSETtag(NULL, $arg_list);
        }
        return $obj;
    }

} // FIELDSETtag