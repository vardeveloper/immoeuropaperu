<?php
/**
 * noframes tag class
 *
 *  The noframes element displays text for
 *  browsers that do not handle frames. The
 *  noframes element goes inside the frameset
 *  element.
 *
 * @package DOM
 */
class NOFRAMEStag extends HTMLTagClass {
    protected $_tag = "noframes";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return NOFRAMEStag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new NOFRAMEStag;
        } else {
            $arg_list = func_get_args();
            return new NOFRAMEStag(NULL, $arg_list);
        }
    }
} // NOFRAMEtag