<?php
/**
 * frameset tag class
 *
 * The frameset element defines a
 * frameset.
 *
 * @package DOM
 */
class FRAMESETtag extends HTMLTagClass {
    protected $_tag = "frameset";

    /**
     * The factory method.
     *
     * NOTE: It comes with the following attributes
     *       defaulted to:
     *       framespacing = "0"
     *       frameborder = "no"
     *
     * @param string the rows attribute
     * @param string the cols attribute
     * @param int the border attribute
     * @return FRAMESETtag object
     */
    public static function factory($rows, $cols, $border="0" ) {
        $attributes = array("border" => $border,
                            "framespacing" => "0",
                            "frameborder" => "no",
                            "rows" => $rows,
                            "cols" => $cols);
        return new FRAMESETtag( $attributes );
    }

} // FRAMESETtag