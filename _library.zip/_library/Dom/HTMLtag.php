<?php
/**
 * html tag class.
 *
 * @package DOM
 */
class HTMLtag extends HTMLTagClass {
    protected $_tag = "html";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return HTMLtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        
        if (!$num_args) {
            return new HTMLtag;
        } else {
            $arg_list = func_get_args();
            
            return new HTMLtag(NULL, $arg_list);
        }
    }
} // HTMLtag