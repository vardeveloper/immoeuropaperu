<?php
/**
 * acronym tag class
 * @package DOM
 */
class ACRONYMtag extends HTMLTagClass {
    protected $_tag = "acronym";

    /**
     * build an <ACRONYM> tag with content.
     *
     *  This is to build an abbreviation.
     *  normally its just
     *  <abbr title="foo bar">foo</abbr>
     *
     * @param string - the title attribute
     * @param mixed - the content for the tag
     * @return  ABBRtag object.
     */
    public static function factory($title, $content) {
        return new ACRONYMtag(array("title"=>$title), $content);
    }

} // ACRONYMtag