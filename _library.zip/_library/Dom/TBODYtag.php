<?php
/**
 * tbody class.
 *
 * Defines a table body.
 *
 * @package DOM
 */
class TBODYtag extends TABLEtag {

    /**
     * Tag definition for class.
     * @var  string
     * @private
     */
    protected $_tag = "tbody";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return TBODYtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new TBODYtag;
        } else {
            $arg_list = func_get_args();
            return new TBODYtag(NULL, $arg_list);
        }
    }

}// TBODYtag