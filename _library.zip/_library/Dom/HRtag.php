<?php
/**
 * hr tag class
 *
 * inserts a horizontal rule.
 *
 * NOTE: All the "presentation attributes"
 *       of the hr element have been
 *       deprecated, in favor of style sheets.
 *
 * @package DOM
 */
class HRtag extends HTMLTagClass {
    protected $_tag = "hr";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    /*function _set_flags() {
    //    parent::_set_flags();
        $this->_flags &= ~(DOM::_NEWLINEAFTEROPENTAG | DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    }*/

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return HRtag object
     */
    public static function factory() {
        return new HRtag;
    }
} // HRtag