<?php
/**
 * Table Header thead class.
 *
 * defines a table header
 *
 * @package DOM
 */
class THEADtag extends TABLEtag {
    protected $_tag = "thead";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return THEADtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new THEADtag;
        } else {
            $arg_list = func_get_args();
            return new THEADtag(NULL, $arg_list);
        }
    }
} // THEAD