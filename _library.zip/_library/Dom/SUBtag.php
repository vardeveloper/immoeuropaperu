<?php
/**
 * sub tag class
 *
 * defines a subscript text
 *
 * @package DOM
 */
class SUBtag extends HTMLTagClass {
    protected $_tag = "sub";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return SUBtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new SUBtag;
        } else {
            $arg_list = func_get_args();
            return new SUBtag(NULL, $arg_list);
        }
    }
} // SUBtag