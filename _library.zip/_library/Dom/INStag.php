<?php
/**
 * ins tag class
 *
 * Defines inserted text.
 *
 * @package DOM
 */
class INStag extends HTMLTagClass {
    protected $_tag = "ins";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return INStag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new INStag;
        } else {
            $arg_list = func_get_args();
            return new INStag(NULL, $arg_list);
        }
    }
} // INStag