<?php
/**
 * form tag
 *
 * The form element creates a form
 * for user input.
 *
 * REQUIRED ATTRIBUTES
 *   action : url
 *            Specifies where to send the
 *            data when the user pushes the
 *            submit button in a form.
 *
 * @package DOM
 */
class FORMtag extends HTMLTagClass {
    protected $_tag = "form";
    //protected $_xhtml_strict_attributes = array("name", "target");

    /**
     * The factory method.
     *
     * @param string  name attribute of the form tag.
     * @param string  the form action.
     * @param string  form method
     * @param string  any extra name='value' attributes for
     *                                the form tag.
     * @return FORMtag object
     */
    public static function factory($name, $action, $method="GET", $attributes=array()) {
        $attribs = array("name" => $name, "action" => $action,
                         "method" => $method);
        $attributes = array_merge( $attribs, $attributes);
        return new FORMtag( $attributes );
    }

    /**
     * This method is used to set the name attribute
     *
     * @param string the name attribute
     */
    public function set_name($name) {
        $this->set_tag_attribute('name', $name);
    }

    /**
     * This method is used to get the name attribute
     *
     * @return string the name attribute
     */
    public function get_name() {
        return $this->get_tag_attribute('name');
    }


    /**
     * This method is used to set the action attribute
     *
     * @param string the action attribute
     */
    public function set_action($action) {
        $this->set_tag_attribute('action', $action);
    }

    /**
     * This method is used to set the action attribute
     *
     * @return string the action attribute
     */
    public function get_action() {
        return $this->get_tag_attribute('action');
    }

    /**
     * This method is used to set the method attribute
     *
     * @param string the method attribute
     */
    public function set_method($method) {
        if ( strcasecmp($method,"GET") !=0 && strcasecmp($method,"POST") !=0 ) {
            user_error("FORMtag::set_method() - INVALID Form method ".$method);
        } else {
            $this->set_tag_attribute('method', $method);
        }
    }

    /**
     * This method is used to set the method attribute
     *
     * @return string the method attribute
     */
    public function get_method() {
        return $this->get_tag_attribute('method');
    }

    /**
     * This method is used to set the onsubmit attribute
     *
     * @param string the onsubmit attribute
     */
    public function set_onsubmit($onsubmit) {
        $this->set_tag_attribute('onsubmit', $onsubmit);
    }

    /**
     * This method is used to set the onsubmit attribute
     *
     * @return string the onsubmit attribute
     */
    public function get_onsubmit() {
        return $this->get_tag_attribute('onsubmit');
    }
} // FORMtag