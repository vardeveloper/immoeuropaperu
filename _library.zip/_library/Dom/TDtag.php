<?php
/**
 * Table data td class.
 *
 * Defines a cell in a table.
 *
 * OPTIONAL ATTRIBUTES
 *  bgcolor : color DEPRICATED DO NOT USE
 *  height : pixels, %  DEPRICATED DO NOT USE
 *  width : pixels, %  DEPRICATED
 *          use styles instead like this <td style="width:100px;">
 *
 * @package DOM
 */
class TDtag extends THtag {
    protected $_tag = "td";

    /**
     * The factory method.
     *
     * @param string class attribute
     * @param string align attribute
     * @param mixed n number of arguments
     *                as content for the tag.
     * @return TDtag object
     */
    public static function factory($class="", $align="") {
        if ($class == "" && $align == "") {
            $attributes = NULL;
        } else {
            $attributes = array();
            if ($class != "") {
                $attributes["class"] = $class;
            }

            if ($align != "") {
                $attributes["align"] = $align;
            }
        }

        $arg_list = func_get_args();
        array_shift($arg_list);
        array_shift($arg_list);
        $obj = new TDtag($attributes, $arg_list);
        return $obj;
    }
}// TDtag