<?php
/**
 * title tag class
 *
 * @package DOM
 */
class TITLEtag extends HTMLTagClass {
    protected $_tag = "title";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return TITLEtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new TITLEtag;
        } else {
            $arg_list = func_get_args();
            return new TITLEtag(NULL, $arg_list);
        }
    }
} // TITLEtag