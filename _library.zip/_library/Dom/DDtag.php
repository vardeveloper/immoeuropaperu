<?php
/**
 * dd tag class
 *
 *  The dd tag defines the description
 *  of the term in a definition list.
 *
 * @package DOM
 */
class DDtag extends HTMLTagClass {
    protected $_tag = "dd";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return DDtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new DDtag;
        } else {
            $arg_list = func_get_args();
            return new DDtag(NULL, $arg_list);
        }
    }

} // DDtag