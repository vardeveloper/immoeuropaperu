<?php
/**
 * li tag class
 *
 * The li tag defines the start of a list
 * item. The li tag is used in both ordered
 * ol and unordered lists ul.
 *
 * OPTIONAL ATTRIBUTES
 *   type : 1, A, a, I, i  DEPRICATED
 *
 * @package DOM
 */
class LItag extends HTMLTagClass {
    protected $_tag = "li";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return LItag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new LItag;
        } else {
            $arg_list = func_get_args();
            return new LItag(NULL, $arg_list);
        }
    }
} // LItag