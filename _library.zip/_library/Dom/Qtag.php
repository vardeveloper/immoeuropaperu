<?php
/**
 * q tag class
 *
 *  The q tag defines the start of a short quotation.
 *
 *  NOTE: The q element does not render as anything
 *        special, you have to use styles to format
 *        the text.
 *
 * @package DOM
 */
class Qtag extends HTMLTagClass {
    protected $_tag = "q";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return Qtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new Qtag;
        } else {
            $arg_list = func_get_args();
            return new Qtag(NULL, $arg_list);
        }
    }
} // Qtag