<?php
/**
 * cite tag class
 *
 * Defines a citation
 *
 * @package DOM
 */
class CITEtag extends HTMLTagClass {
    protected $_tag = "cite";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return CITEtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new CITEtag;
        } else {
            $arg_list = func_get_args();
            return new CITEtag(NULL, $arg_list);
        }
    }

} // CITEtag