<?php
/**
 * font tag class
 *
 * @deprecated use styles instead
 *
 * @package DOM
 */
class FONTtag extends HTMLTagClass {
    protected $_tag = "font";
    protected $_flags = DOM::_FLAGS_HTML_DEPRICATED;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags |= DOM::_DEPRICATED;
    //}

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return FONTtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new FONTtag;
        } else {
            $arg_list = func_get_args();
            return new FONTtag(NULL, $arg_list);
        }
    }

} // FONTtag