<?php
/**
 * col tag class
 *
 *  Defines the attribute values for
 *  one or more columns in a table. You
 *  can only use this element inside a
 *  colgroup.
 *
 * @package DOM
 */
class COLtag extends HTMLTagClass {
    protected $_tag = "col";

    /**
     * The factory method.
     *
     * @param int the width attribute
     * @param string the align attribute
     * @param string the span attribute
     * @return COLtag object
     */
    public static function factory($width='', $align='', $span='') {
        $attributes = array();
        if ($width != '') {
            $attributes["width"] = $width;
        }
        if ($align != '') {
            $attributes["align"] = $align;
        }
        if ($span != '') {
            $attributes["span"] = $span;
        }
        $tag = new COLtag( $attributes );
        return $tag;
    }

} // COLtag