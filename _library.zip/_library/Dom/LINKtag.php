<?php
/**
 * link tag class
 *
 * This element defines the relationship between
 * two linked documents.
 *
 * NOTE:  This element goes only in the head section,
 *        but it can appear any number of times.
 *
 * @package DOM
 */
class LINKtag extends HTMLTagClass {
    protected $_tag = "link";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}

    /**
     * The factory method.
     *
     * @param   string - the href link
     * @param   string - the rel attribute
     * @param   string - the type of content.
     * @return LINKtag object
     */
    public static function factory($href, $rel, $type) {
        return new LINKtag( array("href" => $href,
                                  "rel" => $rel,
                                  "type" => $type));
    }
} // LINKtag