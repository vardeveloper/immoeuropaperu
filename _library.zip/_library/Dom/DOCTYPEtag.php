<?php

/**
 * !doctype tag class
 * @package phpHtmlLib
 */
class DOCTYPEtag extends HTMLTagClass
{

    protected $_tag = "!DOCTYPE";
    protected $_flags = DOM::_FLAGS_XML_DOCTYPE;

    /* function _set_flags() {
      //    parent::_set_flags();
      $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
      $this->_flags |= DOM::_ALWAYS_UPPERCASE | DOM::_NOFINISHSLASHXHTML;
      } */

    /**
     * The factory method.
     *
     * @param string - the document element name (ie. 'HTML')
     * @param string - the source (ie. 'PUBLIC')
     * @param string - link 1 (ie. '-//W3C//DTD XHTML 1.0 Transitional//EN' )
     * @param string - link 2 (ie. 'DTD/xhtml1-transitional.dtd' )
     * @return DOCTYPEtag object
     */
    public static function factory($doc_element, $source = "PUBLIC", $link1 = NULL, $link2 = NULL)
    {
        $attributes = array($doc_element, $source);

        if ($link1 != NULL) {
            array_push($attributes, "\"" . $link1 . "\"");
        }
        if ($link2 != NULL) {
            array_push($attributes, "\"" . $link2 . "\"");
        }

        return new DOCTYPEtag($attributes);
    }

    public static function factoryTo($doc_element, $source = NULL, $link1 = NULL, $link2 = NULL)
    {
        $attributes = array($doc_element, $source);

        if ($link1 != NULL) {
            array_push($attributes, "\"" . $link1 . "\"");
        }
        if ($link2 != NULL) {
            array_push($attributes, "\"" . $link2 . "\"");
        }

        return new DOCTYPEtag($attributes);
    }

}

//!DOCTYPEtag