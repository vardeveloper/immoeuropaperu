<?php
/**
 * base tag class
 *
 * The base element specifies a base URL
 * for all the links in a page.
 *
 * @package DOM
 */
class BASEtag extends HTMLTagClass {
    protected $_tag = "base";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}


    /**
     * The factory method for this tag.
     *
     * @param string the href attribute
     * @return BASEtag object
     */
    public static function factory($href, $target='') {
        $attributes = array('href' => $href);
        if ($target != '') {
            $attributes['target'] = $target;
        }
        return new BASEtag($attributes);
    }

} // BASEtag