<?php
/**
 * input tag
 *
 * The <input> tag defines the start of an input
 * field where the user can enter data.
 *
 * @package DOM
 */
class INPUTtag extends HTMLTagClass {
    protected $_tag = "input";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}


    /**
     * The factory method.
     *
     * NOTE: This wrapper automatically
     *       calls htmlspecialchars() on
     *       the value attribute's data.
     *
     * @param string - the type attribute
     * @param string - the name attribute
     * @param string - the value attribute
     * @param array  - any other name=>value attributes
     *                 for the tag
     * @return INPUTtag object
     */
    public static function factory($type, $name, $value='', $attributes=array()) {
        $attrib = array( "type" => $type,"name" => $name,"value" => $value);
        $attributes = array_merge( $attrib, $attributes );
        return new INPUTtag( $attributes );
    }


    /**
     * add a single attribute (name="value")
     *
     * We override this to prevent the value from
     * being injected javascript.
     *
     * {@source }
     *
     * @param   string  $name   attribute name
     * @param   mixed   $value  the value.
     * @return none
     */
    function set_tag_attribute( $name, $value=NULL ) {
        if (stristr('value', $name)) {
            $value = htmlspecialchars($value, ENT_QUOTES);
        }
        $this->_attributes[$name] = $value;
    }

    /**
     * add multiple attributes (name="value")
     *
     * We override this to prevent the value from
     * being injected javascript.
     *
     * {@source }
     *
     * @param   array   $attributes Associative array of name="value" pairs of
     *                              tag atributes.
     *                              ie array("border"=>"0", "class"=>"hover");
     * @return none
     */
    function set_tag_attributes( $attributes=array() ) {
        if (!isset($this->_attributes)) {
            $this->_attributes = array();
        }

        if (isset($attributes['value'])) {
            $attributes['value'] = htmlspecialchars($attributes['value'], ENT_QUOTES);
        }

        $this->_attributes = array_merge($this->_attributes, $attributes);
    }

} // INPUTtag