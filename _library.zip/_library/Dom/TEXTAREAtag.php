<?php
/**
 * textarea tag class
 *
 * Defines a text-area (a multi-line text
 *  input control).
 *  The default font in the text-area is fixed pitch.
 *
 * REQUIRED ATTRIBUTES
 *  cols : number
 *         The width of the textarea, in characters.
 *
 *  rows : number
 *         The height of  the textarea, in rows
 *
 * OPTIONAL ATTRIBUTES
 *  wrap : soft, hard, off  DEPRICATED DO NOT USE
 *
 * @package DOM
 */
class TEXTAREAtag extends HTMLTagClass {
    protected $_tag = "textarea";

    function _set_flags() {
    //    parent::_set_flags();
        $this->_flags &= ~(DOM::_INDENT | DOM::_NEWLINEAFTEROPENTAG);
    }

    /**
     * The factory method.
     *
     * @param string rows attribute
     * @param string cols attribute
     * @param mixed n number of arguments
     *                as content for the tag.
     * @return TEXTAREAtag object
     */
    public static function factory($rows, $cols) {
        $arg_list = func_get_args();
        array_shift($arg_list);
        array_shift($arg_list);
        $obj = new TEXTAREAtag(array('rows' => $rows,
                                     'cols' => $cols), $arg_list);
        return $obj;
    }

} // TEXTAREAtag