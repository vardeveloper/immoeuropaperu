<?php
/**
 * legend tag class
 *
 * The legend element defines a caption
 * for a fieldset.
 *
 * @package DOM
 */
class LEGENDtag extends HTMLTagClass {
    protected $_tag = "legend";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return LEGENDtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new LEGENDtag;
        } else {
            $arg_list = func_get_args();
            return new LEGENDtag(NULL, $arg_list);
        }
    }

} // LEGENDtag