<?php
/**
 * strong tag class
 *
 * Renders as strong emphasized text
 * @package DOM
 *
 */
class STRONGtag extends HTMLTagClass {
    protected $_tag = "strong";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return STRONGtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new STRONGtag;
        } else {
            $arg_list = func_get_args();
            return new STRONGtag(NULL, $arg_list);
        }
    }
} // STRONGtag