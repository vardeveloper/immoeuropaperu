<?php
/**
 * em tag class
 *
 *  Renders as emphasized text
 *
 * @package DOM
 */
class EMtag extends HTMLTagClass {
    protected $_tag = "em";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return DTtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new EMtag;
        } else {
            $arg_list = func_get_args();
            return new EMtag(NULL, $arg_list);
        }
    }

} // EMtag