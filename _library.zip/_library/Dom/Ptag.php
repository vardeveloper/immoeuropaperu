<?php
/**
 * p tag class
 *
 * The p tag defines a paragraph.
 *
 * OPTIONAL ATTRIBUTES
 *  align : left, center, right DEPRICATED DO NOT USE
 *
 * @package DOM
 */
class Ptag extends HTMLTagClass {
    protected $_tag = "p";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return Ptag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new Ptag;
        } else {
            $arg_list = func_get_args();
            return new Ptag(NULL, $arg_list);
        }
    }
} // Ptag