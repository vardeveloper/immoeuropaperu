<?php
/**
 * option tag class
 *
 *  The option element defines an option in the
 *  drop-down box.
 *
 * @package DOM
 */
class OPTIONtag extends HTMLTagClass {
    protected $_tag = "option";
    protected $_flags = DOM::_FLAGS_XML_NO_NEWLINE_AFTER_OPEN;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~DOM::_NEWLINEAFTEROPENTAG;
    //}

    /**
     * The factory method.
     *
     * @param string value attribute
     * @param string the content
     * @param boolean SELECTED? or not
     * @return OPTIONtag object
     */
    public static function factory($value, $content, $selected=FALSE) {
        $attributes = array('value' => $value);

        if ($selected) {
            if ($GLOBALS["HTML_RENDER_TYPE"] == DOM::HTML) {
                $attributes[] = 'SELECTED';
            } else {
                $attributes['selected'] = 'selected';
            }
        }
        return $tag = new OPTIONtag( $attributes, $content );
    }

} // OPTIONtag