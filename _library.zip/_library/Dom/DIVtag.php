<?php
/**
 * div tag class
 *
 * The div tag defines the start of a
 * division/section in a document.
 *
 * NOTE: Browsers usually place a line break
 *       before the <div> tag.
 *
 * @package DOM
 */
class DIVtag extends HTMLTagClass {
    protected $_tag = "div";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return DIVtag object
     */
    public static function factory($class = "") {
        if ($class == "") {
            $attributes = NULL;
        } else {
            $attributes = array('class' => $class);
        }

        $arg_list = func_get_args();
        array_shift($arg_list);
        $obj = new DIVtag($attributes, $arg_list);
        return $obj;
    }

} // DIVtag