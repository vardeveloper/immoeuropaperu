<?php
/**
 * big tag class
 *
 * renders as 'bigger' text.
 * @package DOM
 */
class BIGtag extends HTMLTagClass {
    protected $_tag = "big";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return BIGtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new BIGtag;
        } else {
            $arg_list = func_get_args();
            return new BIGtag(NULL, $arg_list);
        }
    }

} // BIGtag