<?php
/**
 * iframe tag class
 *
 * The iframe element creates an inline
 * frame that contains another document.
 *
 * @package DOM
 */
class IFRAMEtag extends HTMLTagClass {
    protected $_tag = "iframe";

    /**
     * The factory method.
     *
     * @param string the src attribute
     * @param string the width attribute
     * @param string the height attribute
     * @param string the scrolling attribute
     * @return Itag object
     */
    public static function factory($src, $width="", $height="", $scrolling="") {
        $attributes = array("src" => $src);
        if ($width != "") {
            $attributes["width"] = $width;
        }
        if ($height != "") {
            $attributes["height"] = $height;
        }
        if ($width != "") {
            $attributes["scrolling"] = $scrolling;
        }
        return new IFRAMEtag( $attributes );
    }
} // IFRAMEtag