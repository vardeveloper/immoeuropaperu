<?php
/**
 * sup tag class
 *
 * defines a superscript text
 *
 * @package DOM
 */
class SUPtag extends HTMLTagClass {
    protected $_tag = "sup";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return SUPtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new SUPtag;
        } else {
            $arg_list = func_get_args();
            return new SUPtag(NULL, $arg_list);
        }
    }
} // SUPtag