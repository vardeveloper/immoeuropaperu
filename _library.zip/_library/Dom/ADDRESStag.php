<?php
/**
 * address tag class
 * @package DOM
 */
class ADDRESStag extends HTMLTagClass {
    protected $_tag = "address";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return ADDRESStag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new ADDRESStag;
        } else {
            $arg_list = func_get_args();
            return new ADDRESStag(NULL, $arg_list);
        }
    }

} // ADDRESStag