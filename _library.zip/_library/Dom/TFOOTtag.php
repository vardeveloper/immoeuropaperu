<?php
/**
 * tfoot tag class
 *
 * @package DOM
 */
class TFOOTtag extends TABLEtag {
    protected $_tag = "tfoot";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return TFOOTtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new TFOOTtag;
        } else {
            $arg_list = func_get_args();
            return new TFOOTtag(NULL, $arg_list);
        }
    }
} // TFOOTtag