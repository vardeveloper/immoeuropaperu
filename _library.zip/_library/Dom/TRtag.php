<?php
/**
 * Table Row tr class.
 * @package DOM
 */
class TRtag extends HTMLTagClass {
    protected $_tag = "tr";

    /**
     * Holds the default attributes for all <td>'s
     * @var array
     * @private
     */
    protected $_default_td_attributes = NULL;

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return TRtag object
     */
    public static function factory($class="") {
        //we need to make sure all arguments
        //pass through the add method
        //because add automagically converts
        //strings to LItag objects.
        if ($class == "") {
            $attributes = NULL;
        } else {
            $attributes = array('class' => $class);
        }

        $tag = new TRtag($attributes);
        $num_args = func_num_args();
        if ($num_args > 1) {
            $arg_list = func_get_args();
            array_shift($arg_list);
            foreach( $arg_list as $arg) {
                $tag->add($arg);
            }
        }

        return $tag;
    }

    //****************************************************************
    // TR specific routines.
    //****************************************************************

    /**
     * Sets the default attributes for <td>'s
     * that are added to the table.  If there are
     * any attributes set for the <td> it won't use
     * the defaults.
     *
     * @param array $attributes - the default attributes
     */
    public function set_default_td_attributes( $attributes=array() ) {
        $this->_default_td_attributes = $attributes;
    }

    /**
     * add content onto content stack
     * adds content to tag as a FIFO.
     * You can have n number of parameters.
     * each one will get added in succession to the content.
     *
     * we override this from the parent so we can auto detect if
     * the user is adding raw strings instead of objects.
     * If they are trying to add raw strings, then we wrap that in
     * a TDtag object, since you can't add anything other then a <TD> or
     * <TH> to a <TR>.
     * @param   mixed   $content - either string, or tag object.
     * @access  public
     */
    public function add() {
        $args = func_get_args();

        foreach( $args as $content) {
            if (!is_object($content) || (!($content instanceOf TDtag) &&
                                         !($content instanceOf THtag)) ) {
                //$content is raw (string)
                //lets wrap it in a <td> object
                $td = new TDtag( $this->_default_td_attributes );
                $td->add( $content );
                parent::add( $td );
            } else {
                //looks like this is some object
                //let the user do it.
                //should we only let them add a
                //<TD> object?
                parent::add( $content );
            }
        }
    }

} // TRtag