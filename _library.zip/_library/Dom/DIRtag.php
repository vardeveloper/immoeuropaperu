<?php
/**
 * dir tag class
 *
 * The <dir> tag defines the start of a
 *
 * DEPRECATED
 *
 * @package DOM
 */
class DIRtag extends HTMLTagClass {
    protected $_tag = "dir";
    protected $_flags = DOM::_FLAGS_HTML_DEPRICATED;


    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return DIRtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new DIRtag;
        } else {
            $arg_list = func_get_args();
            return new DIRtag(NULL, $arg_list);
        }
    }

} // DIRtag