<?php
/**
 * map tag class
 *
 *  Defines an image map. An image map is an
 *  image with clickable regions.
 *
 * @package DOM
 */
class MAPtag extends HTMLTagClass {
    protected $_tag = "map";

    /**
     * The factory method.
     *
     * @param string the name attribute
     * @param   mixed n number of arguments
     *                as content for the tag.
     * @return MAPtag object
     */
    public static function factory($name) {
        $attributes = array('name' => $name);
        $num_args = func_num_args();
        if ($num_args<=1) {
            $obj = new MAPtag($attributes);
        } else {
            $arg_list = func_get_args();
            array_shift($arg_list);
            $obj = new MAPtag($attributes, $arg_list);
        }
        return $obj;
    }
} // MAPtag