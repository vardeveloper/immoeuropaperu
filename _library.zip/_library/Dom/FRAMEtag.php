<?php
/**
 * frame tag class
 *
 * Defines a sub window (a frame).
 *
 * @package DOM
 */
class FRAMEtag extends HTMLTagClass {
    protected $_tag = "frame";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}

    /**
     * The factory method.
     * NOTE: this comes with the following attribtes
     *      defaulted to:
     *      marginwidth = "0"
     *      marginheight = "0"
     *      noresize
     *      frameborder = "0"
     *
     * @param string the "name" attribute
     * @param string the "src" atribute
     * @param string the "scrolling" attribute
     * @return FRAMEtag object
     */
    public static function factory($name, $src, $scrolling="no") {
        $attributes = array("name" => $name,
                            "src" => $src,
                            "scrolling" => $scrolling,
                            "marginwidth" => "0",
                            "marginheight" => "0",
                            "noresize",
                            "frameborder" => "no");
        return new FRAMEtag( $attributes );
    }

} // FRAMEtag