<?php
/**
 * dt tag class
 *
 * The dt tag defines the start of a
 * definition list.
 *
 * @package DOM
 */
class DTtag extends HTMLTagClass {
    protected $_tag = "dt";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return DTtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new DTtag;
        } else {
            $arg_list = func_get_args();
            return new DTtag(NULL, $arg_list);
        }
    }

} // DTtag