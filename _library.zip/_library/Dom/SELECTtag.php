<?php
/**
 * select tag class
 *
 * @todo create factory method
 *
 *  The select element creates a drop-down box.
 *
 * @package DOM
 */
class SELECTtag extends HTMLTagClass {
    protected $_tag = "select";


    /**
     * The factory to build a SELECTtag object
     * with OPTIONtags
     *
     * @param string name of the select.
     * @param array an array of name value pairs for
     *              the options.  the format is
     *              array( "LABEL" => VALUE );
     *              each <option value="VALUE"> LABEL </option>
     *              ie
     *              array( "test" => "foo")  would give an option
     *              of <option value="foo"> test </option>
     *
     *              NOTE: this also supports automatic building of
     *                    the optgroup. Just pass in an array of
     *                    array("foogroup" => array("name" => "value1",
     *                                              "name2" => "value2"),
     *                          "bargroup" => array("blah" => "foo"));
     *
     *
     * @param mixed This can be either a string or an array.
     *              If its a string then, it will be the selected
     *              option value
     *              <option value="foo" SELECTED>foo</option>
     *              If it is an array, then all of the option
     *              values will be marked as SELECTED.  This only
     *              makes sense to do if the multiple_flag  is true.
     * @param boolean is this a multiple selection select box?
     * @param array additionnal attributes to the select tag
     *
     * @return SELECTtag object
     */
    public static function factory($name, $options, $selected=NULL,
                                   $multiple_flag=FALSE, $attribs=FALSE) {
        if ( !$attribs ) {
            $attribs = array();
        }

        $attribs["name"] = $name;
        $select = new SELECTtag( $attribs );
        if ( $multiple_flag ) {
            $select->set_tag_attribute('multiple', 'multiple');
        }

        if ( is_array($options) ) {
            while ( list($label, $value) = each($options) ) {
                //see if they wanted an option group
                if ( is_array($value) ) {
                    $option = OPTGROUPtag::factory($label);
                    foreach( $value as $optname => $optvalue ) {
                        $selected_value = SELECTtag::form_select_is_selected($optvalue, $selected);
                        $option->add(OPTIONtag::factory($optvalue, $optname, $selected_value));
                    }
                } else {
                    $selected_value = SELECTtag::form_select_is_selected($value, $selected);
                    $option = OPTIONtag::factory($value, htmlspecialchars($label), $selected_value);
                }

                $select->add( $option );
            }
        }

        return $select;
    }

    /**
     * This function is used by form_select
     * to determin if a value is selected or not.
     *
     * @param string value
     * @param string selected value
     * @return boolean
     */
    public static function form_select_is_selected($value, $selected) {
        $selected_value = false;

        if ( is_array($selected) ) {
            //looks like this is a multiple select box
            //lets see if the value is in the array
            if ( in_array($value, $selected) ) {
                $selected_value = TRUE;
            }
        } else {
            //must be a string
            if ( $value == $selected ) {
                $selected_value = TRUE;
            }
        }
        return $selected_value;
    }
} // SELECTtag