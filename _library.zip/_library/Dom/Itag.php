<?php
/**
 * i tag class
 *
 * Renders as italic text
 *
 * @package DOM
 */
class Itag extends HTMLTagClass {
    protected $_tag = "i";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return Itag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new Itag;
        } else {
            $arg_list = func_get_args();
            return new Itag(NULL, $arg_list);
        }
    }
} // Itag