<?php
/**
 * b tag class
 * @package DOM
 */
class Btag extends HTMLTagClass {
    protected $_tag = "b";
    protected $_flags = DOM::_FLAGS_XML_NO_NEWLINE_AFTER_OPEN;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~DOM::_NEWLINEAFTEROPENTAG;
    //}

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return Btag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new Btag;
        } else {
            $arg_list = func_get_args();
            return new Btag(NULL, $arg_list);
        }
    }

} // Btag