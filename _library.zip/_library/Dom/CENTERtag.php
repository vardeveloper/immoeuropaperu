<?php
/**
 * center tag class.
 * this is a depricated html tag, but
 * browsers still support it
 *
 * @deprecated
 * @package DOM
 */
class CENTERtag extends HTMLTagClass {
    protected $_tag = "center";
    protected $_flags = DOM::_FLAGS_HTML_DEPRICATED;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags |= DOM::_DEPRICATED;
    //}

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return CENTERtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new CENTERtag;
        } else {
            $arg_list = func_get_args();
            return new CENTERtag(NULL, $arg_list);
        }
    }

} // CENTERtag