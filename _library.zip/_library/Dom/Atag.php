<?php
/**
 * a tag class
 * @tutorial HTMLTagClass.cls#constructor
 * @package DOM
 */
class Atag extends HTMLTagClass {
    protected $_tag = "a";
    protected $_flags = DOM::_FLAGS_XML_NO_NEWLINE_AFTER_OPEN;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~DOM::_NEWLINEAFTEROPENTAG;
    //}

    /**
     * build an href with content and attributes.
     *
     * @tutorial HTMLTagClass.cls#helper
     *
     * @author Walt A. Boring
     * @param   string the url to go to.
     * @param   string the visible link text.
     * @param   string the css class to use.
     * @param   string the target browser
     *                 window/frame for the url.
     * @param   string the title attribute
     * @return  Atag object.
     */
    public static function factory($url, $content, $class=NULL,
                                   $target=NULL, $title=NULL) {
        $attributes = array("href" => $url);
        if ($class) {
            $attributes["class"] = $class;
        }

        if ($target) {
            $attributes["target"] = $target;
        }

        if ($title) {
            $attributes["title"] = $title;
        }

        $a = new Atag($attributes, $content);
        $a->set_collapse();
        return $a;
    }

    /**
     * Create a mailto link
     *
     * @param   string $email - the email address
     *                            for the mailto
     *    @param   string $subject - the subject for
     *    the email
     *    @param   string $body - the body conent
     *    for the email
     *    @param   string $cc = the cc email address.
     */
    public static function mailto($email, $subject=NULL, $body=NULL, $cc=NULL) {
        $mailto = "mailto:".$email."?";
        if ( $subject ) {
            $mailto .= "subject=".rawurlencode($subject);
        }
        if ( $body ) {
            $mailto .= "&body=".rawurlencode($body);
        }
        if ( $cc ) {
            $mailto .= "&cc=".rawurlencode($cc);
        }

        return Atag::factory($mailto, $email);
    }
    
    

} // Atag