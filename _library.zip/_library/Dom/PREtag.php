<?php
/**
 * pre tag class
 *
 * The pre element defines preformatted text.
 * The text enclosed in the pre element usually
 * preserves spaces and line breaks. The text
 * renders in a fixed-pitch font.
 *
 * @package DOM
 */
class PREtag extends HTMLTagClass {
    protected $_tag = "pre";

    function _set_flags() {
    //    parent::_set_flags();
        $this->_flags &= ~DOM::_INDENT;
    }

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return PREtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new PREtag;
        } else {
            $arg_list = func_get_args();
            return new PREtag(NULL, $arg_list);
        }
    }
} // PREtag