<?php
/**
 * blockquote tag class
 *
 * This tag defines a long
 * quotation block
 *
 * @package DOM
 */
class BLOCKQUOTEtag extends HTMLTagClass {
    protected $_tag = "blockquote";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return BLOCKQUOTEtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new BLOCKQUOTEtag;
        } else {
            $arg_list = func_get_args();
            return new BLOCKQUOTEtag(NULL, $arg_list);
        }
    }

} // BLOCKQUOTEtag