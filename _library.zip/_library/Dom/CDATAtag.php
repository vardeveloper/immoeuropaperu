<?php

/**
 * A simple wrapper for standard XML
 * CDATA section data
 * @package DOM
 */
class CDATAtag extends XMLTagClass {
    var $_tag = "CDATA[";
    var $_tag_prefix = "<![";
    var $_tag_postfix = "]]>";

	function __construct() {
		parent::__construct($this->_tag, array());
        $this->_flags &= ~DOM::_CLOSETAGREQUIRED;
        $this->_flags |= DOM::_NOFINISHSLASHXHTML;

		$num_args = func_num_args();
        for ($i=0;$i<$num_args;$i++) {
            $this->add(func_get_arg($i));
		}
	}

	function _render_open_tag( $indent_level, $finish_slash=FALSE ) {
		//get the indent level
		$indent = $this->_render_indent( $indent_level );

		$xml = $indent . $this->_tag_prefix . $this->_tag;

		if ($this->_flags & DOM::_NEWLINEAFTEROPENTAG) {
			$xml .= "\n";
		}
		return $xml;
	}

	function _render_close_tag($indent_level) {
		$indent = "";
		if (($this->_flags & DOM::_INDENT) && ($this->_flags & DOM::_NEWLINEAFTEROPENTAG)) {
			$indent = $this->_render_indent($indent_level);
		}
		$str = $indent .$this->_tag_postfix;

		if ($this->_flags & DOM::_NEWLINEAFTERCLOSETAG) {
			$str .= "\n";
		}
		return $str;
	}
}