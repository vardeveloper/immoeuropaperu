<?php
/**
 * area tag class
 * @package DOM
 */
class AREAtag extends HTMLTagClass {
    protected $_tag = "area";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}

    /**
     * build an <AREA> tag with content.
     *
     * @param string - the href for the area
     * @param string - the coords value
     *                 circle x,y,radius
     *                 poly x1,y1,...xn,yn
     *                 left,top,right,bottom
     * @param string - the shape
     *                 DEFAULT: rect
     *                 circle, rect, poly, default
     * @param string - the alt text
     * @param string - the target
     *                 _blank, _parent, _self, _top
     * @param string - the title text
     *
     * @return  AREAtag object.
     */
    public static function factory($href, $coords, $shape="rect",
                                   $alt="", $target="", $title="") {
        $attributes = array("href" => $href,
                            "coords" => $coords,
                            "shape" => $shape);
        if ($alt != "") {
            $attributes["alt"] = $alt;
        }

        if ($target != "") {
            $attributes["target"] = $target;
        }

        if ($title != "") {
            $attributes["title"] = $title;
        }

        $tag = new AREAtag( $attributes );
        return $tag;
    }

} // AREAtag