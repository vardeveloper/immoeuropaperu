<?php
/**
 * colgroup tag class
 *
 * Defines groups of table columns.
 *  This element is only valid
 * inside the <table> tag.
 *
 * NOTE: The colgroup element is an empty
 *       element that contains attributes
 *       only. To create columns, you must
 *       specify td elements within a tr
 *       element.
 *
 * @package DOM
 */
class COLGROUPtag extends HTMLTagClass {
    protected $_tag = "colgroup";

    /**
     * The factory method.
     *
     * @param array attributes
     * @return COLGROUPtag object
     */
    public static function factory($attributes=NULL) {
        $tag = new COLGROUPtag( $attributes );
        return $tag;
    }

} // COLGROUPtag