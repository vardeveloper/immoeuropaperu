<?php
/**
 * kbd tag class
 *
 * Defines keyboard text
 *
 * @package DOM
 */
class KBDtag extends HTMLTagClass {
    protected $_tag = "kbd";

    /**
     * The factory method.
     *
     * @param mixed - the content for the tag
     * @return KBDtag object
     */
    public static function factory() {
        $num_args = func_num_args();
        if (!$num_args) {
            return new KBDtag;
        } else {
            $arg_list = func_get_args();
            return new KBDtag(NULL, $arg_list);
        }
    }
} // KBDtag