<?php
/**
 * br tag class
 *
 * This tag inserts a single line break;
 *
 * @package DOM
 */
class BRtag extends HTMLTagClass {
    protected $_tag = "br";
    protected $_flags = DOM::_FLAGS_XML_OPEN_ONLY;

    //function _set_flags() {
    //    parent::_set_flags();
    //    $this->_flags &= ~(DOM::_CONTENTREQUIRED | DOM::_CLOSETAGREQUIRED);
    //}

    /**
     * The factory method.
     *
     * @param int - the number of
     *              br tags you want
     * @param string the class attribute
     * @return BRtag object or Container
     */
    public static function factory($num=1, $class=NULL) {
        if ($class !== null) {
            $attributes = array('class' => $class);
        } else {
            $attributes = NULL;
        }

        if ($num == 1){
            return new BRtag($attributes);
        } else if ($num > 1) {
            $obj = new Container;
            $obj->set_collapse();
            for ($i=0; $i<$num;$i++) {
                $obj->add( new BRtag($attributes) );
            }
            return $obj;
        } else if ($num <= 0) {
            return NULL;
        }
    }

} // BRtag